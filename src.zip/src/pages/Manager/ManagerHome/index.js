import React from 'react'

import TasksPage from '../TasksPages'

const ManagerHome = () => {

    return (
        <TasksPage />
    );
}

export default ManagerHome